package model;

public class Concept {
	String observedProperty = "";
	String sensor = "";
	String sensorOutput = "";
	String measurementUnit = "";

	/**
	 * @return the observedProperty
	 */
	public String getObservedProperty() {
		return observedProperty;
	}

	/**
	 * @param observedProperty
	 *            the observedProperty to set
	 */
	public void setObservedProperty(String observedProperty) {
		this.observedProperty = observedProperty;
	}

	/**
	 * @return the sensor
	 */
	public String getSensor() {
		return sensor;
	}

	/**
	 * @param sensor
	 *            the sensor to set
	 */
	public void setSensor(String sensor) {
		this.sensor = sensor;
	}

	/**
	 * @return the sensorOutput
	 */
	public String getSensorOutput() {
		return sensorOutput;
	}

	/**
	 * @param sensorOutput
	 *            the sensorOutput to set
	 */
	public void setSensorOutput(String sensorOutput) {
		this.sensorOutput = sensorOutput;
	}

	/**
	 * @return the measurementUnit
	 */
	public String getMeasurementUnit() {
		return measurementUnit;
	}

	/**
	 * @param measurementUnit
	 *            the measurementUnit to set
	 */
	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}

}
