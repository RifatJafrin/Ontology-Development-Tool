package model;

import java.util.List;

public class DBProperty {

	String property;
	int type;
	List domain;
	List ranges;

	/**
	 * @return the property
	 */
	public String getProperty() {
		return property;
	}

	/**
	 * @param property
	 *            the property to set
	 */
	public void setProperty(String property) {
		this.property = property;
	}

	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * @return the domain
	 */
	public List getDomain() {
		return domain;
	}

	/**
	 * @param domain
	 *            the domain to set
	 */
	public void setDomain(List domain) {
		this.domain = domain;
	}

	/**
	 * @return the range
	 */
	public List getRange() {
		return ranges;
	}

	/**
	 * @param range
	 *            the range to set
	 */
	public void setRange(List range) {
		this.ranges = range;
	}

}
