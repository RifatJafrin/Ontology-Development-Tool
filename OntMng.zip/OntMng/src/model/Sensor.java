package model;

public class Sensor {

	String name;
	String attachedSensor ;
	String systemSpecification;
	String dimensions ;
	String ranges;
	String totalSensorNo ;
	String otherInfo;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the attachedSensor
	 */
	public String getAttachedSensor() {
		return attachedSensor;
	}
	/**
	 * @param attachedSensor the attachedSensor to set
	 */
	public void setAttachedSensor(String attachedSensor) {
		this.attachedSensor = attachedSensor;
	}
	/**
	 * @return the systemSpecification
	 */
	public String getSystemSpecification() {
		return systemSpecification;
	}
	/**
	 * @param systemSpecification the systemSpecification to set
	 */
	public void setSystemSpecification(String systemSpecification) {
		this.systemSpecification = systemSpecification;
	}
	/**
	 * @return the dimensions
	 */
	public String getDimensions() {
		return dimensions;
	}
	/**
	 * @param dimensions the dimensions to set
	 */
	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}
	/**
	 * @return the ranges
	 */
	public String getRanges() {
		return ranges;
	}
	/**
	 * @param ranges the ranges to set
	 */
	public void setRanges(String ranges) {
		this.ranges = ranges;
	}
	/**
	 * @return the totalSensorNo
	 */
	public String getTotalSensorNo() {
		return totalSensorNo;
	}
	/**
	 * @param totalSensorNo the totalSensorNo to set
	 */
	public void setTotalSensorNo(String totalSensorNo) {
		this.totalSensorNo = totalSensorNo;
	}
	/**
	 * @return the otherInfo
	 */
	public String getOtherInfo() {
		return otherInfo;
	}
	/**
	 * @param otherInfo the otherInfo to set
	 */
	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}
	
	
}
