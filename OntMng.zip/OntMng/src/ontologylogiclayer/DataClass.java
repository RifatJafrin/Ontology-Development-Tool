package ontologylogiclayer;

import com.hp.hpl.jena.rdf.model.Model;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.OutputStreamWriter;
import edu.stanford.smi.protegex.owl.model.OWLModel;

public class DataClass implements java.io.Serializable {

    private OWLModel fModel;
    
    public DataClass(OWLModel Model) {
        this.fModel = Model;
    }


	private void writeObject(java.io.ObjectOutputStream out) throws IOException {
         ((Model) fModel).write(out);
    };
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
         String s="";
        ((Model) fModel).read(in, s);
    };
    private void readObjectNoData() throws ObjectStreamException {
    };

    public void writeInStream(OutputStreamWriter oos) {
        ((Model) fModel).write(oos);
    }
}
