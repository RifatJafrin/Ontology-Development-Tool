package ontologylogiclayer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import model.Concept;
import model.DBConcept;
import model.Ontology;
import model.Sensor;

import com.hp.hpl.jena.util.FileUtils;

import customexception.CustomException;
import dataaccesslayer.DataAccessManager;
import edu.stanford.smi.protege.exception.OntologyLoadException;
import edu.stanford.smi.protegex.owl.ProtegeOWL;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;

public class OntologyManager {

	private OWLModel model = null;

	private static OWLModel defaultModel = null;
	public static int baseOntologyID=0;
	private static String sourceFileName = "F:/WorkspaceOntology/initModel.owl";
	private static String dstFileNameDir = "F:/WorkspaceOntology/OntologyRepository/";

	public OWLModel getDefaultModel() {
		return defaultModel;
	}

	public String createModelfromDB(int ontologyID) throws SQLException, OntologyLoadException, FileNotFoundException {
		// read basic model
		OWLModel owlModel = null;
		File file = new File(sourceFileName);
		FileInputStream in = null;
		in = new FileInputStream(file);
		owlModel = ProtegeOWL.createJenaOWLModelFromInputStream(in);
		
		// Get all concepts from database

		OWLNamedClass ObservedProperty = owlModel
				.getOWLNamedClass("base:ObservedProperty");
		OWLNamedClass Sensor = owlModel.getOWLNamedClass("ssn:Sensor");
		OWLNamedClass SensorOutput = owlModel
				.getOWLNamedClass("ssn:SensorOutput");
		OWLNamedClass UnitOfMeasure = owlModel
				.getOWLNamedClass("base:MeasurementUnit");

		// OWLObjectProperty hasUnit =
		// owlModel.getOWLObjectProperty("base:hasUnit");

		
		HashMap<Integer, model.DBConcept> classes = null;
		classes = DataAccessManager
					.getAllConceptRecords(ontologyID);
		
		for (int id : classes.keySet()) {
			String classname = classes.get(id).getConcept();
			int parentID = classes.get(id).getParent();

			switch (parentID) {
			case DataAccessManager.CONCEPT_PARENT_OBSERVEDTYPE:
				owlModel.createOWLNamedSubclass("base:" + classname,
						ObservedProperty);
				break;
			case DataAccessManager.CONCEPT_PARENT_SENSOR:
				owlModel.createOWLNamedSubclass("base:" + classname, Sensor);
				break;

			case DataAccessManager.CONCEPT_PARENT_SENSOROUTPUT:
				owlModel.createOWLNamedSubclass("base:" + classname,
						SensorOutput);
				break;

			case DataAccessManager.CONCEPT_PARENT_UNIT:
				owlModel.createOWLNamedSubclass("base:" + classname,
						UnitOfMeasure);
				break;
			default:
				continue;
			}
		}

		HashMap<String, model.DBProperty> properties = null;
		properties = DataAccessManager
					.getAllPropertyRecords(ontologyID);
		
		for (String property : properties.keySet()) {
			int type = properties.get(property).getType();
			ArrayList<String> domains = null;
			ArrayList<String> ranges = null;
			Collection domainClasses = new ArrayList<OWLNamedClass>();
			Collection rangeClasses = new ArrayList<OWLNamedClass>();
			
			switch (type) {
			case DataAccessManager.DATA_PROPERTY:
				OWLDatatypeProperty dataProperty = owlModel.getOWLDatatypeProperty("base:" + property) ;
				OWLDatatypeProperty dataPropertySSN = owlModel.getOWLDatatypeProperty("ssn:" + property) ;

				domains = (ArrayList<String>) properties.get(property)
						.getDomain();
				if(domains!=null){
					for (String strConceptId : domains) {
						String className = classes.get(
								Integer.parseInt(strConceptId)).getConcept();
						if(className==null || className.length()<=0){
							continue;
						}
						domainClasses.add(owlModel.getOWLNamedClass("base:"
								+ className));

					}
					if (dataProperty!=null)
					dataProperty.setDomains(domainClasses);
					else if (dataPropertySSN!=null)
						dataPropertySSN.setDomains(domainClasses);
	
				}
				
				ranges = (ArrayList<String>) properties.get(property)
						.getRange();
				if(ranges!=null){
					for (String strConceptId : ranges) {
						String className = classes.get(
								Integer.parseInt(strConceptId)).getConcept();
						if(className==null || className.length()<=0){
							continue;
						}
						rangeClasses.add(owlModel.getOWLNamedClass("base:"
								+ className));

					}
					if (dataProperty!=null)
					dataProperty.setRanges(ranges);
					else if (dataPropertySSN!=null)
						dataPropertySSN.setRanges(ranges);
	
				}
				
				break;
			case DataAccessManager.OBJECT_PROPERTY:
				OWLObjectProperty objectProperty = owlModel.getOWLObjectProperty("base:" + property);
				OWLObjectProperty objectPropertySSN = owlModel.getOWLObjectProperty("ssn:" + property);

				
				domains = (ArrayList<String>) properties.get(property)
						.getDomain();
				if(domains!=null){
					for (String strConceptId : domains) {
						String className = classes.get(
								Integer.parseInt(strConceptId)).getConcept();
						if(className==null || className.length()<=0){
							continue;
						}
						domainClasses.add(owlModel.getOWLNamedClass("base:"
								+ className));

					}
					if (objectProperty!=null)
						objectProperty.setDomains(domainClasses);
					else if (objectPropertySSN!=null)
						objectPropertySSN.setDomains(domainClasses);
		
	
				}
				
				ranges = (ArrayList<String>) properties.get(property)
						.getRange();
				if(ranges!=null){
					for (String strConceptId : ranges) {
						String className = classes.get(
								Integer.parseInt(strConceptId)).getConcept();
						if(className==null || className.length()<=0){
							continue;
						}
						rangeClasses.add(owlModel.getOWLNamedClass("base:"
								+ className));

					}
					if (objectProperty!=null)
						objectProperty.setRanges(rangeClasses);
					else if (objectPropertySSN!=null)
						objectPropertySSN.setRanges(rangeClasses);
	
				}
				
				break;

			default:
				continue;
			}
		}
		String ontoName=DataAccessManager.getOntologyName(ontologyID);
		if(ontoName==null || ontoName.length()==0){
			ontoName="NotFoundName";
		}
		Collection errors = new ArrayList();
		((JenaOWLModel) owlModel).save(new File(dstFileNameDir+ontoName+".owl").toURI(),
				FileUtils.langXMLAbbrev, errors);

		return dstFileNameDir+ontoName+".owl";

	}

		
	private boolean doesContains(String str, int key){
		if(str==null || str.length()==0) return false;
		
		boolean isFound= false;
		
		String[] list= str.split(",");
		for(int i=0; i<list.length; i++){
			if(Integer.parseInt(list[i])==key){
				isFound= true;
				break;
			}
		}
		return isFound;
	}

	public void insertConcept(Concept concept, int ontologyID) throws CustomException {
		int observation, sensor, output, unit, groupID;
	
		try{
		observation=DataAccessManager.getMaxId(ontologyID)+1;
		groupID= DataAccessManager.getGroupId(observation-1, ontologyID)+1;
		if(groupID<0){
			groupID=0;
		}
				
		
		DataAccessManager.insertConcept(observation, concept.getObservedProperty(), DataAccessManager.CONCEPT_PARENT_OBSERVEDTYPE,groupID, ontologyID);
		sensor=observation+1; //DataAccessManager.getMaxId()+1;
		DataAccessManager.insertConcept(sensor, concept.getSensor(), DataAccessManager.CONCEPT_PARENT_SENSOR,groupID, ontologyID);
		output=sensor+1; //DataAccessManager.getMaxId()+1;
		DataAccessManager.insertConcept(output, concept.getSensorOutput(), DataAccessManager.CONCEPT_PARENT_SENSOROUTPUT,groupID, ontologyID);
		unit=output+1; //DataAccessManager.getMaxId()+1;
		DataAccessManager.insertConcept(unit, concept.getMeasurementUnit(), DataAccessManager.CONCEPT_PARENT_UNIT,groupID, ontologyID);
		
		
		String hasUnitDomains=DataAccessManager.getDomains("hasUnit", ontologyID);
		String hasUnitRanges=DataAccessManager.getRanges("hasUnit", ontologyID);
		if(hasUnitDomains==null||hasUnitDomains.length()==0){
			DataAccessManager.updateDomains("hasUnit", Integer.toString(output), ontologyID);
		}else if(!doesContains(hasUnitDomains, output)){
			hasUnitDomains=hasUnitDomains+","+output;
			DataAccessManager.updateDomains("hasUnit", hasUnitDomains, ontologyID);
		}
		
		if(hasUnitRanges==null||hasUnitRanges.length()==0){
			DataAccessManager.updateRanges("hasUnit", Integer.toString(unit), ontologyID);
		}else if(!doesContains(hasUnitRanges, unit)){
			hasUnitRanges=hasUnitRanges+","+unit;
			DataAccessManager.updateRanges("hasUnit", hasUnitRanges, ontologyID);
		}
		
		
		String observedByDomains=DataAccessManager.getDomains("observedBy", ontologyID);
		String observedByRanges=DataAccessManager.getRanges("observedBy", ontologyID);
		if(observedByDomains==null||observedByDomains.length()==0){
			DataAccessManager.updateDomains("observedBy", Integer.toString(output), ontologyID);
		}else if(!doesContains(observedByDomains, output)){
			observedByDomains=observedByDomains+","+output;
			DataAccessManager.updateDomains("observedBy", observedByDomains, ontologyID);
		}
		
		if(observedByRanges==null||observedByRanges.length()==0){
			DataAccessManager.updateRanges("observedBy", Integer.toString(sensor), ontologyID);
		}else if(!doesContains(observedByRanges, sensor)){
			observedByRanges=observedByRanges+","+sensor;
			DataAccessManager.updateRanges("observedBy", observedByRanges, ontologyID);
		}
		
		String observesDomains=DataAccessManager.getDomains("observes", ontologyID);
		String observesRanges=DataAccessManager.getRanges("observes", ontologyID);
		if(observesDomains==null||observesDomains.length()==0){
			DataAccessManager.updateDomains("observes", Integer.toString(sensor), ontologyID);
		}else if(!doesContains(observesDomains, sensor)){
			observesDomains=observesDomains+","+sensor;
			DataAccessManager.updateDomains("observes", observesDomains, ontologyID);
		}
		
		if(observesRanges==null||observesRanges.length()==0){
			DataAccessManager.updateRanges("observes", Integer.toString(observation), ontologyID);
		}else if(!doesContains(observesRanges, observation)){
			observesRanges=observesRanges+","+observation;
			DataAccessManager.updateRanges("observes", observesRanges, ontologyID);
		}
		
		String hasLatitude=DataAccessManager.getDomains("hasLatitude", ontologyID);
		if(hasLatitude==null||hasLatitude.length()==0){
			DataAccessManager.updateDomains("hasLatitude", Integer.toString(sensor), ontologyID);
		}else if(!doesContains(hasLatitude, sensor)){
			hasLatitude=hasLatitude+","+sensor;
			DataAccessManager.updateDomains("hasLatitude", hasLatitude, ontologyID);
		}
		
		
		String hasLongitude=DataAccessManager.getDomains("hasLongitude", ontologyID);
		if(hasLongitude==null||hasLongitude.length()==0){
			DataAccessManager.updateDomains("hasLongitude", Integer.toString(sensor), ontologyID);
		}else if(!doesContains(hasLongitude, sensor)){
			hasLongitude=hasLongitude+","+sensor;
			DataAccessManager.updateDomains("hasLongitude", hasLongitude, ontologyID);
		}
		
		
		
		String hasSensorName=DataAccessManager.getDomains("hasSensorName", ontologyID);
		if(hasSensorName==null||hasSensorName.length()==0){
			DataAccessManager.updateDomains("hasSensorName", Integer.toString(sensor), ontologyID);
		}else if(!doesContains(hasSensorName, sensor)){
			hasSensorName=hasSensorName+","+sensor;
			DataAccessManager.updateDomains("hasSensorName", hasSensorName, ontologyID);
		}
		
		
		
		String hasSensingTime=DataAccessManager.getDomains("hasSensingTime", ontologyID);
		if(hasSensingTime==null||hasSensingTime.length()==0){
			DataAccessManager.updateDomains("hasSensingTime", Integer.toString(output), ontologyID);
		}else if(!doesContains(hasSensingTime, output)){
			hasSensingTime=hasSensingTime+","+output;
			DataAccessManager.updateDomains("hasSensingTime", hasSensingTime, ontologyID);
		}
		
		
		
		
		String hasValue=DataAccessManager.getDomains("hasValue", ontologyID);
		if(hasValue==null||hasValue.length()==0){
			DataAccessManager.updateDomains("hasValue", Integer.toString(output), ontologyID);
		}else if(!doesContains(hasValue, output)){
			hasValue=hasValue+","+output;
			DataAccessManager.updateDomains("hasValue", hasValue, ontologyID);
		}
		
		}catch(Exception ex){
			throw new CustomException("insert concept failed!");
		}
		
		
		/*
		 * hasUnit- tempot, degcel
		 * observedBy--- tempout, tempsensor
		 * observes---tempsensor, temp
		 * hasLatitude--tempsensor
		 * hasLongitude---tempsensor
		 * hasSensingTime---- TemperatureOutput
		 * hasValue-----TemperatureOutput
		 * hasSensorName--tempsensor
		 */
		

	}

	public List<Concept> getAllConcepts(int ontologyID) {
		HashMap<Integer, ArrayList<model.DBConcept>> concepts = null;
		try {
			concepts = DataAccessManager.getAllConcepts(ontologyID);
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		List<Concept> list= new ArrayList<Concept>();
		for(int groupID: concepts.keySet()){
			ArrayList<model.DBConcept> groupedConcepts=concepts.get(groupID);
			Concept concept= new Concept();
			for(model.DBConcept dbConcept:groupedConcepts){
				switch(dbConcept.getParent()){
				case DataAccessManager.CONCEPT_PARENT_OBSERVEDTYPE:
					concept.setObservedProperty(dbConcept.getConcept());
				break;	
				
				case DataAccessManager.CONCEPT_PARENT_SENSOR:
					concept.setSensor(dbConcept.getConcept());
					break;
					
				case DataAccessManager.CONCEPT_PARENT_SENSOROUTPUT:
					concept.setSensorOutput(dbConcept.getConcept());
					break;
					
				case DataAccessManager.CONCEPT_PARENT_UNIT:
					concept.setMeasurementUnit(dbConcept.getConcept());
					break;
				}
			}
		
			list.add(concept);
			
		}
		return list;
	}

	public Concept getConcept(String observation, int ontologyID) throws CustomException {
		HashMap<Integer, ArrayList<model.DBConcept>> concepts = null;
		try {
			//concepts = DataAccessManager.getAllConcepts(ontologyID);
			concepts = DataAccessManager.getRequiredConcept(observation, ontologyID);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
		//new linw
		Concept concept= new Concept();
		//------------------
		//List<Concept> list= new ArrayList<Concept>();
		for(int groupID: concepts.keySet()){
			ArrayList<model.DBConcept> groupedConcepts=concepts.get(groupID);
			//Concept concept= new Concept();
			for(model.DBConcept dbConcept:groupedConcepts){
				switch(dbConcept.getParent()){
				case DataAccessManager.CONCEPT_PARENT_OBSERVEDTYPE:
					concept.setObservedProperty(dbConcept.getConcept());
				break;	
				
				case DataAccessManager.CONCEPT_PARENT_SENSOR:
					concept.setSensor(dbConcept.getConcept());
					break;
					
				case DataAccessManager.CONCEPT_PARENT_SENSOROUTPUT:
					concept.setSensorOutput(dbConcept.getConcept());
					break;
					
				case DataAccessManager.CONCEPT_PARENT_UNIT:
					concept.setMeasurementUnit(dbConcept.getConcept());
					break;
				}
			}
		
			//list.add(concept);
			
		}
		//return list.get(0);
		return concept;
	}

	public void updateConcept(Concept concept, String observation, int ontologyID) throws CustomException {
		Concept masterConcept= getConcept(observation, ontologyID);	
		
		try{
		DataAccessManager.updateConcept(concept.getObservedProperty(), masterConcept.getObservedProperty(), ontologyID); 
		DataAccessManager.updateConcept(concept.getSensor(), masterConcept.getSensor(), ontologyID);
		DataAccessManager.updateConcept(concept.getSensorOutput(), masterConcept.getSensorOutput(), ontologyID);
		DataAccessManager.updateConcept(concept.getMeasurementUnit(), masterConcept.getMeasurementUnit(), ontologyID);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private String removeID(String idList, List<Integer> id){
		if(idList==null || idList.length()==0){
			return idList;
		}
		List<String> ids = Arrays.asList(idList.split("\\s*,\\s*"));
		
		StringBuffer resIds= new StringBuffer();
		for(String var: ids){
			if(var!=null && var.length()>0 && !id.contains(Integer.parseInt(var))){
				resIds.append(var);
				resIds.append(",");
			}
		}
		
		return resIds.toString();
	}
	
	private void updateProperties(List<Integer> id, int ontologyID) throws SQLException{
		String hasUnitDomains=DataAccessManager.getDomains("hasUnit", ontologyID);
		String hasUnitRanges=DataAccessManager.getRanges("hasUnit", ontologyID);
		DataAccessManager.updateDomains("hasUnit", removeID(hasUnitDomains, id), ontologyID);
		DataAccessManager.updateRanges("hasUnit", removeID(hasUnitRanges, id), ontologyID);
		
		String observedByDomains=DataAccessManager.getDomains("observedBy", ontologyID);
		String observedByRanges=DataAccessManager.getRanges("observedBy", ontologyID);
		DataAccessManager.updateDomains("observedBy", removeID(observedByDomains, id), ontologyID);
		DataAccessManager.updateRanges("observedBy", removeID(observedByRanges, id), ontologyID);
		
		String observesDomains=DataAccessManager.getDomains("observes", ontologyID);
		String observesRanges=DataAccessManager.getRanges("observes", ontologyID);
		DataAccessManager.updateDomains("observes", removeID(observesDomains, id), ontologyID);
		DataAccessManager.updateRanges("observes", removeID(observesRanges, id), ontologyID);
		
		String hasLatitude=DataAccessManager.getDomains("hasLatitude", ontologyID);
		DataAccessManager.updateDomains("hasLatitude", removeID(hasLatitude, id), ontologyID);
		
		
		String hasLongitude=DataAccessManager.getDomains("hasLongitude", ontologyID);
		DataAccessManager.updateDomains("hasLongitude", removeID(hasLongitude, id), ontologyID);
		
		String hasSensorName=DataAccessManager.getDomains("hasSensorName", ontologyID);
		DataAccessManager.updateDomains("hasSensorName", removeID(hasSensorName, id), ontologyID);
		
		String hasSensingTime=DataAccessManager.getDomains("hasSensingTime", ontologyID);
		DataAccessManager.updateDomains("hasSensingTime", removeID(hasSensingTime, id), ontologyID);
		
		
		String hasValue=DataAccessManager.getDomains("hasValue", ontologyID);
		DataAccessManager.updateDomains("hasValue", removeID(hasValue, id), ontologyID);
		
	}
	
	public void deleteConcept(String observation, int ontologyID) throws  CustomException {
		Concept masterConcept= getConcept(observation, ontologyID);	
		try{
			List<Integer> ids= new ArrayList<Integer>();
			ids.add(DataAccessManager.getId(masterConcept.getObservedProperty(), ontologyID));
			ids.add(DataAccessManager.getId(masterConcept.getSensor(), ontologyID));
			ids.add(DataAccessManager.getId(masterConcept.getSensorOutput(), ontologyID));
			ids.add(DataAccessManager.getId(masterConcept.getMeasurementUnit(), ontologyID));
			
			updateProperties(ids, ontologyID);
			
			
			
		DataAccessManager.deleteConcept(masterConcept.getObservedProperty(), ontologyID); 
		DataAccessManager.deleteConcept(masterConcept.getSensor(), ontologyID);
		DataAccessManager.deleteConcept(masterConcept.getSensorOutput(), ontologyID);
		DataAccessManager.deleteConcept(masterConcept.getMeasurementUnit(), ontologyID);
		}catch(Exception e){
			throw new CustomException("delete concept faild !");
		}
		
	}

	public void createOntology(int ontologyID, String[] selectedObservedProperties) throws Exception {
			//init properties
		DataAccessManager.createProperty("hasUnit",1,ontologyID);
		DataAccessManager.createProperty("observedBy",1,ontologyID);
		DataAccessManager.createProperty("observes",1,ontologyID);
		DataAccessManager.createProperty("hasValue",0,ontologyID);
		DataAccessManager.createProperty("hasLatitude",0,ontologyID);
		DataAccessManager.createProperty("hasLongitude",0,ontologyID);
		DataAccessManager.createProperty("hasSensingTime",0,ontologyID);
		DataAccessManager.createProperty("hasSensorName",0,ontologyID);
		
		//insert concepts from base ontology
		
		for(String observeredProperty: selectedObservedProperties){
			Concept concept=getConcept(observeredProperty, baseOntologyID);
			insertConcept(concept, ontologyID); // it also update properties inside the method
		}
		
		
	}
	
	
	public void deleteOntology(int ontologyID) throws SQLException{
		DataAccessManager.deleteProperties(ontologyID);
		DataAccessManager.deleteConcepts(ontologyID);
	}

	public List<Ontology> getAllOntologies() throws SQLException {
		return DataAccessManager.getAllOntologies();
				
	}
	
	public List<Sensor> getAllSensors() throws SQLException {
		return DataAccessManager.getSensors();
				
	}

	public int insertOntology(Ontology ontology) throws SQLException {
		int id=DataAccessManager.getMaxOntologyId()+1;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date today = Calendar.getInstance().getTime();        
		String strDate = df.format(today);
		
		DataAccessManager.insertOntology(id, ontology.getName(), ontology.getDescription(), strDate);
		return id;
		
	}

	public void insertSensor(Sensor sensor) throws SQLException {
		
		DataAccessManager.insertSensor(sensor.getName(), sensor.getAttachedSensor(), sensor.getSystemSpecification(), 
        sensor.getDimensions(), sensor.getRanges(), sensor.getTotalSensorNo(), sensor.getOtherInfo()  );
		
				
	}
	
	public boolean isUnique(int ontologyID, String newConcept) throws SQLException{
		if(newConcept==null || newConcept.length()==0){
			return false;
		}
		ArrayList<String> concepts= DataAccessManager.getAllEntities(ontologyID);
		for(String c: concepts){
			if (c.equalsIgnoreCase(newConcept)){
				return false;
			}
		}
		
		return true;
	}
	
	public void sendOntology(int ontologyID) throws SQLException, FileNotFoundException, OntologyLoadException{
		OWLModel owlModel = null;
		WebClientPOST client=new WebClientPOST();
		String ontoName=DataAccessManager.getOntologyName(ontologyID);
		File file = new File(dstFileNameDir+ontoName+".owl");
		FileInputStream in = null;
		in = new FileInputStream(file);
		owlModel = ProtegeOWL.createJenaOWLModelFromInputStream(in);
		DataClass obj = new DataClass(owlModel);
		try {
			client.PostModel(obj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
	}
}




/*
 * //for each concept, update model
 * 
 * OWLObjectProperty hasUnit =
 * owlModel.getOWLObjectProperty("base:hasUnit");
 * hasUnit.setDomain(owlModel
 * .getOWLNamedClass("base:TemperatureOutput")); //
 * hasUnit.setRange(owlModel.getOWLNamedClass("base:DegreeCelsius"));
 * //hasUnit.setRange(owlModel.getOWLNamedClass("base:Farenhight"));
 * 
 * Collection classes=new ArrayList<OWLNamedClass>();
 * classes.add(owlModel.getOWLNamedClass("base:DegreeCelsius"));
 * classes.add(owlModel.getOWLNamedClass("base:Farenhight"));
 * hasUnit.setRanges(classes);
 * 
 * 
 * // observedBy OWLObjectProperty observedBy =
 * owlModel.getOWLObjectProperty("ssn:observedBy");
 * observedBy.setDomain(
 * owlModel.getOWLNamedClass("base:TemperatureOutput"));
 * observedBy.setRange
 * (owlModel.getOWLNamedClass("base:TemperatureSensor"));
 * 
 * //observes OWLObjectProperty observes =
 * owlModel.getOWLObjectProperty("ssn:observes");
 * observes.setDomain(owlModel
 * .getOWLNamedClass("base:TemperatureSensor"));
 * observes.setRange(owlModel.getOWLNamedClass("base:Temperature"));
 * 
 * //hasLatitude //domain TemperatureSensor OWLDatatypeProperty
 * hasLatitude = owlModel.getOWLDatatypeProperty("base:hasLatitude");
 * hasLatitude
 * .setDomain(owlModel.getOWLNamedClass("base:TemperatureSensor"));
 * 
 * //hasLongitude // domain TemperatureSensor OWLDatatypeProperty
 * hasLongitude = owlModel.getOWLDatatypeProperty("base:hasLongitude");
 * hasLongitude
 * .setDomain(owlModel.getOWLNamedClass("base:TemperatureSensor"));
 * 
 * 
 * 
 * //hasSensingTime // domain TemperatureOutput
 * 
 * OWLDatatypeProperty hasSensingTime =
 * owlModel.getOWLDatatypeProperty("base:hasSensingTime");
 * hasSensingTime
 * .setDomain(owlModel.getOWLNamedClass("base:TemperatureSensor"));
 * 
 * 
 * //hasValue // domain TemperatureOutput
 * 
 * OWLDatatypeProperty hasValue =
 * owlModel.getOWLDatatypeProperty("ssn:hasValue");
 * hasValue.setDomain(owlModel
 * .getOWLNamedClass("base:TemperatureOutput"));
 * 
 * //hasSensorName //domain TemperatureSensor OWLDatatypeProperty
 * hasSensorName =
 * owlModel.getOWLDatatypeProperty("base:hasSensorName");
 * hasSensorName.setDomain
 * (owlModel.getOWLNamedClass("base:TemperatureOutput"));
 */
// save model


/*public void saveModel(String srcFile, String dstFile) {
// read basic model
OWLModel owlModel = null;
File file = new File(srcFile);
FileInputStream in = null;

try {
	in = new FileInputStream(file);
} catch (FileNotFoundException e1) {
	e1.printStackTrace();
	return;
}

try {
	owlModel = ProtegeOWL.createJenaOWLModelFromInputStream(in);
} catch (OntologyLoadException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	return;
}

// Get all concepts from database

// for each concept, update model

OWLNamedClass ObservedProperty = owlModel
		.getOWLNamedClass("base:ObservedProperty");
owlModel.createOWLNamedSubclass("base:Temperature", ObservedProperty);

OWLNamedClass Sensor = owlModel.getOWLNamedClass("ssn:Sensor");
owlModel.createOWLNamedSubclass("base:TemperatureSensor", Sensor);

OWLNamedClass SensorOutput = owlModel
		.getOWLNamedClass("ssn:SensorOutput");
owlModel.createOWLNamedSubclass("base:TemperatureOutput", SensorOutput);

OWLNamedClass UnitOfMeasure = owlModel
		.getOWLNamedClass("base:UnitOfMeasure");
owlModel.createOWLNamedSubclass("base:DegreeCelsius", UnitOfMeasure);
owlModel.createOWLNamedSubclass("base:Farenhight", UnitOfMeasure);

OWLObjectProperty hasUnit = owlModel
		.getOWLObjectProperty("base:hasUnit");
hasUnit.setDomain(owlModel.getOWLNamedClass("base:TemperatureOutput"));
// hasUnit.setRange(owlModel.getOWLNamedClass("base:DegreeCelsius"));
// hasUnit.setRange(owlModel.getOWLNamedClass("base:Farenhight"));

Collection classes = new ArrayList<OWLNamedClass>();
classes.add(owlModel.getOWLNamedClass("base:DegreeCelsius"));
classes.add(owlModel.getOWLNamedClass("base:Farenhight"));
hasUnit.setRanges(classes);

// observedBy
OWLObjectProperty observedBy = owlModel
		.getOWLObjectProperty("ssn:observedBy");
observedBy.setDomain(owlModel
		.getOWLNamedClass("base:TemperatureOutput"));
observedBy
		.setRange(owlModel.getOWLNamedClass("base:TemperatureSensor"));

// observes
OWLObjectProperty observes = owlModel
		.getOWLObjectProperty("ssn:observes");
observes.setDomain(owlModel.getOWLNamedClass("base:TemperatureSensor"));
observes.setRange(owlModel.getOWLNamedClass("base:Temperature"));

// hasLatitude
// domain TemperatureSensor
OWLDatatypeProperty hasLatitude = owlModel
		.getOWLDatatypeProperty("base:hasLatitude");
hasLatitude.setDomain(owlModel
		.getOWLNamedClass("base:TemperatureSensor"));

// hasLongitude
// domain TemperatureSensor
OWLDatatypeProperty hasLongitude = owlModel
		.getOWLDatatypeProperty("base:hasLongitude");
hasLongitude.setDomain(owlModel
		.getOWLNamedClass("base:TemperatureSensor"));

// hasSensingTime
// domain TemperatureOutput

OWLDatatypeProperty hasSensingTime = owlModel
		.getOWLDatatypeProperty("base:hasSensingTime");
hasSensingTime.setDomain(owlModel
		.getOWLNamedClass("base:TemperatureSensor"));

// hasValue
// domain TemperatureOutput

OWLDatatypeProperty hasValue = owlModel
		.getOWLDatatypeProperty("ssn:hasValue");
hasValue.setDomain(owlModel.getOWLNamedClass("base:TemperatureOutput"));

// hasSensorName
// domain TemperatureSensor
OWLDatatypeProperty hasSensorName = owlModel
		.getOWLDatatypeProperty("base:hasSensorName");
hasSensorName.setDomain(owlModel
		.getOWLNamedClass("base:TemperatureOutput"));

// save model
Collection errors = new ArrayList();
((JenaOWLModel) owlModel).save(new File(dstFile).toURI(),
		FileUtils.langXMLAbbrev, errors);

}
*/
