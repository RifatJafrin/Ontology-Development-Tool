package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import model.Concept;
import model.Ontology;
import model.Sensor;
import ontologylogiclayer.OntologyManager;

import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import customexception.CustomException;
import edu.stanford.smi.protege.exception.OntologyLoadException;

@Controller
public class FrontEndController {
	OntologyManager logicManager = new OntologyManager();

	// ==================================Index page=====================================================

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView Home() {
		ModelAndView model = new ModelAndView("home");
		return model;
	}

	
	@RequestMapping(value = "/index.html", method = RequestMethod.GET)
	public ModelAndView Index() {
		ModelAndView model = new ModelAndView("home");

		return model;
	}
	
	//============================ Error page =================================================================
	
	@ExceptionHandler(CustomException.class)
	public ModelAndView exception(CustomException e) {
		ModelAndView model = new ModelAndView("error");
		model.addObject("exception", e.getMessage());
		return model;

	}

	// =====================================Add Concept===================================================

	@RequestMapping(value = "/addConcept", method = RequestMethod.POST)
	public ModelAndView addConcept(@ModelAttribute("concept") Concept concept)
			throws CustomException {
		try {
			if(logicManager.isUnique(logicManager.baseOntologyID, concept.getObservedProperty()) &&
					logicManager.isUnique(logicManager.baseOntologyID, concept.getSensor())&&
					logicManager.isUnique(logicManager.baseOntologyID, concept.getSensorOutput())
					//logicManager.isUnique(logicManager.baseOntologyID, concept.getMeasurementUnit())
					){
				logicManager.insertConcept(concept, logicManager.baseOntologyID);
			}else{
				throw new CustomException(
						"duplicate or empty string found !");
			}
			
		} catch (Exception e) {
			throw new CustomException(
					"insert concept to base ontology failed !");
		}
		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage",
				"Successfully added new concept to Base Ontology &#9786;");
		return model;

	}

	// ========================================Update Concept================================================

	@RequestMapping(value = "/editConcept/{observation}", method = RequestMethod.POST, params = "update")
	public ModelAndView editConcept(@ModelAttribute("concept") Concept concept,
			@PathVariable("observation") String observation)
			throws CustomException {
		try {
			     /*if(logicManager.isUnique(logicManager.baseOntologyID, concept.getObservedProperty()) &&
					logicManager.isUnique(logicManager.baseOntologyID, concept.getSensor()) &&
					logicManager.isUnique(logicManager.baseOntologyID, concept.getSensorOutput()) &&
					logicManager.isUnique(logicManager.baseOntologyID, concept.getMeasurementUnit())
					){*/
			      //if(logicManager.isUnique(logicManager.baseOntologyID, concept.getMeasurementUnit())
					//			){
			        logicManager.updateConcept(concept, observation, 0);
			        //logicManager.updateConcept(concept, observation, logicManager.baseOntologyID);
		     	//}
			     //else{
				//throw new CustomException(
					//	"duplicate or empty string found !");
			//}
			
		} catch (Exception e) {
			throw new CustomException(
					"update concept to base ontology failed !");
		}

		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage",
				"Successfully updated to Base Ontology &#9786;");
		return model;
	}

	@RequestMapping(value = "/editConcept/{observation}", method = RequestMethod.POST, params = "delete")
	public ModelAndView delConcept(@ModelAttribute("concept") Concept concept,
			@PathVariable("observation") String observation)
			throws CustomException {
		try {
			//logicManager.deleteConcept(observation, logicManager.baseOntologyID);
			logicManager
			.deleteConcept(observation, 0);

		} catch (Exception e) {
			throw new CustomException(
					"delete concept from base ontology failed !");
		}

		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage",
				"Successfully deleted from Base Ontology &#9786;");
		return model;
	}

	@RequestMapping(value = "/editConcept/{observation}", method = RequestMethod.POST, params = "cancel")
	public ModelAndView cancelUpdate(
			@ModelAttribute("concept") Concept concept,
			@PathVariable("observation") String observation) {

		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage", "Last action was cancelled.");
		return model;
	}

	@RequestMapping(value = "/edit/{observation}", method = RequestMethod.GET)
	public ModelAndView editPage(@PathVariable("observation") String observation)
			throws CustomException {
		ModelAndView model = new ModelAndView("updateConcept");
		Concept concept = new Concept();
		try {
			//concept = logicManager.getConcept(observation, logicManager.baseOntologyID);
			  concept = logicManager.getConcept(observation,0);

		} catch (Exception e) {
			throw new CustomException(
					"Retrieve concept from base ontology failed !");
		}

		model.addObject("lists", concept);
		return model;
	}


	
	//============================================ create ontology =====================

	@RequestMapping(value = "/createOntology", method = RequestMethod.POST)
	public ModelAndView createOntology(
			@ModelAttribute("ontology") Ontology ontology) throws CustomException {
		int id=-1;
		try {
			 id=logicManager.insertOntology(ontology);
		} catch (Exception e) {
			throw new CustomException(
					"insert concept to base ontology failed !");
		}
		ModelAndView model = new ModelAndView("createOntologyConcepts");
		model.addObject("id", id);
		try {
			model.addObject("lists",
					logicManager.getAllConcepts(logicManager.baseOntologyID));
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all concepts from base ontology failed !");
		}
		//model.addObject("generalMessage","Successfully added new ontology&#9786;");
		return model;

	}
	
	
	//============================================ create Sensor =====================

	@RequestMapping(value = "/addSensor", method = RequestMethod.POST)
	public ModelAndView createSensor(
			@ModelAttribute("sensor") Sensor sensor) throws CustomException {
		try {
			 logicManager.insertSensor(sensor);
		} catch (Exception e) {
			throw new CustomException(
					"Insert Sensor information to the system is failed !");
		}
		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage",
				"Successfully added new sensor to the system &#9786;");
		return model;

	}
	

	
	
	//======================================= download ontology ======================================
	
	@RequestMapping(value = "/createOntologyConcepts/{id}", method = RequestMethod.POST)
	public ModelAndView createOntologyConcepts(
			@RequestParam(value = "selection", required = false) String[] selectedObservedProperties,
			@PathVariable("id") int id) throws CustomException {
		try {
			logicManager.createOntology(id, selectedObservedProperties);
		} catch (Exception e) {
			throw new CustomException("create ontology failed !");
		}
		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage", "Successfully created ontology");
		return model;

	}
	
	
	@RequestMapping(value = "/download/{ontologyID}", method = RequestMethod.GET)
	public void doDownload(@PathVariable("ontologyID") int ontologyID,
			HttpServletResponse res) throws CustomException {
		String fileName = null;
		try {
			fileName = logicManager.createModelfromDB(ontologyID);
		} catch (FileNotFoundException e1) {
			throw new CustomException("Base ontology not found !");

		} catch (SQLException e1) {
			throw new CustomException("database error !");

		} catch (OntologyLoadException e1) {
			throw new CustomException("ontology load failed !");
		}

		// "C:/base.owl";
		File f = new File(fileName);
		System.out.println("Loading file " + fileName + "("
				+ f.getAbsolutePath() + ")");
		if (f.exists()) {
			res.setContentType("application/pdf");
			res.setContentLength(new Long(f.length()).intValue());
			res.setHeader("Content-Disposition",
					"attachment; filename=base.owl");
			try {
				FileCopyUtils.copy(new FileInputStream(f),
						res.getOutputStream());
			} catch (FileNotFoundException e) {
				throw new CustomException("generated file not found !");
			} catch (IOException e) {
				throw new CustomException("file read error !");
			}
		} else {
			System.out.println("File" + fileName + "(" + f.getAbsolutePath()
					+ ") does not exist");
			throw new CustomException("File does not exist");
		}
	}
	
	
	//================================ Update Network =====================================================
	
	@RequestMapping(value = "/updateNetwork/{ontologyID}", method = RequestMethod.GET)
	public  ModelAndView  doUpdateNetwork(@PathVariable("ontologyID") int ontologyID,
			HttpServletResponse res) throws CustomException {
		try {
			 logicManager.sendOntology(ontologyID);
		} catch (FileNotFoundException e1) {
			throw new CustomException("Ontology Send to network failed !");

		} catch (SQLException e1) {
			throw new CustomException("database error !");

		} catch (OntologyLoadException e1) {
			throw new CustomException("ontology load failed !");
		}
	
		ModelAndView model = new ModelAndView("generalMessage");
		model.addObject("generalMessage","Updated network successfully.");
		
		return model;
	
	}
	
	
	

	// =============================================== Menu options here===============================
	// ================================================================================================

	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "home")
	public ModelAndView menuHome() {
		ModelAndView model = new ModelAndView("home");

		return model;
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "add")
	public ModelAndView menuAdd() {
		ModelAndView model = new ModelAndView("addConcept");
		return model;
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "update")
	public ModelAndView menuUpdate() throws CustomException {
		ModelAndView model = new ModelAndView("updateConcepts");
		try {
			model.addObject("lists",
					logicManager.getAllConcepts(logicManager.baseOntologyID));
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all concepts from base ontology failed !");
		}
		return model;
	}
	
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "display")
	public ModelAndView menuDisplay() throws CustomException {
		ModelAndView model = new ModelAndView("allConcepts");

		try {
			model.addObject("lists",
					logicManager.getAllConcepts(logicManager.baseOntologyID));
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all concepts from base ontology failed !");
		}

		return model;
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "createOntology")
	public ModelAndView menuCreateOntology(HttpServletResponse res)
			throws CustomException {
		ModelAndView model = new ModelAndView("createOntology");
		return model;
	}

	

	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "ontologies")
	public ModelAndView menuShowOntologies() throws CustomException {
		ModelAndView model = new ModelAndView("showOntologies");

		try {
			model.addObject("lists", logicManager.getAllOntologies());
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all ontologies from base ontology failed !");
		}

		return model;
	}

	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "sensor")
	public ModelAndView menuShowSensor() throws CustomException {
		ModelAndView model = new ModelAndView("sensorRepository");

		try {
			model.addObject("lists", logicManager.getAllSensors());
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all ontologies from base ontology failed !");
		}

		return model;
	}


	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "download")
	public ModelAndView menuDownload(HttpServletResponse res)
			throws CustomException {
		ModelAndView model = new ModelAndView("downloads");

		try {
			model.addObject("lists", logicManager.getAllOntologies());
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all ontologies from base ontology failed !");
		}

		return model;
	}

	
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "addSensor")
	public ModelAndView menuAddSensor(HttpServletResponse res)
			throws CustomException {
		ModelAndView model = new ModelAndView("addSensor");
		return model;
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET, params = "updateNetwork")
	public ModelAndView menuUpdateNetwork(HttpServletResponse res)
			throws CustomException {
		ModelAndView model = new ModelAndView("updateNetwork");

		try {
			model.addObject("lists", logicManager.getAllOntologies());
		} catch (Exception e) {
			throw new CustomException(
					"retrieve all ontologies from base ontology failed !");
		}

		return model;
	}
}
	

/*
 * @RequestMapping(value = "/menu", method = RequestMethod.GET, params =
 * "treeview") public ModelAndView menuTreeView() { ModelAndView model = new
 * ModelAndView("Show");
 * 
 * return model; }
 * 
 * @RequestMapping(value = "/menu", method = RequestMethod.GET, params =
 * "make") public ModelAndView menuMake() { ModelAndView model = new
 * ModelAndView("Partial");
 * 
 * try { model.addObject("lists", logicManager.getAllConcepts()); } catch
 * (Exception e) { e.printStackTrace(); } return model; }
 * 
 * @RequestMapping(value = "/menu", method = RequestMethod.GET, params =
 * "send") public ModelAndView menuSend() { ModelAndView model = new
 * ModelAndView("Show");
 * 
 * return model; }
 */




/*
 * 
 * @RequestMapping(value = "/concept", method = RequestMethod.GET) public
 * ModelAndView getSensorInfo() {
 * 
 * ModelAndView model = new ModelAndView("addConcept");
 * 
 * return model; }
 * 
 * 
 * 
 * @RequestMapping(value = "/create/{fileName}", method = RequestMethod.GET)
 * public ModelAndView saveModel(@PathVariable("fileName") String
 * dstFileName) { if (dstFileName == null || dstFileName.length() == 0) {
 * dstFileName = "test.owl"; }
 * 
 * try { logicManager.createModelfromDB(dstFileName + ".owl"); } catch
 * (Exception e) { e.printStackTrace(); }
 * 
 * ModelAndView model = new ModelAndView("Home");
 * 
 * return model; }
 * 
 * @RequestMapping(value = "/show", method = RequestMethod.GET) public
 * ModelAndView showAllConcepts() {
 * 
 * ModelAndView model = new ModelAndView("Show");
 * 
 * try { model.addObject("lists", logicManager.getAllConcepts()); } catch
 * (Exception e) { e.printStackTrace(); }
 * 
 * return model; }
 * 
 * 
 * 
 * @RequestMapping(value = "/delConcept/{observation}", method =
 * RequestMethod.POST) public ModelAndView deleteConcept(
 * 
 * @ModelAttribute("concept") Concept concept,
 * 
 * @PathVariable("observation") String observation) {
 * 
 * try { logicManager.deleteConcept(observation, baseOntologyID); } catch
 * (Exception e) { // TODO Auto-generated catch block e.printStackTrace(); }
 * ModelAndView model = new ModelAndView("Home");
 * 
 * return model;
 * 
 * }
 */


/*
@RequestMapping(value = "/createOntologyInfo", method = RequestMethod.POST)
public ModelAndView createOntologyInfo(
		@ModelAttribute("ontology") Ontology ontology)
		throws CustomException {
	int id = -1;
	try {
		id = logicManager.insertOntology(ontology);
	} catch (Exception e) {
		throw new CustomException("insert ontology failed !");
	}
	ModelAndView model = new ModelAndView("createOntologyConcepts");
	model.addObject("id", id);
	return model;
}*/
