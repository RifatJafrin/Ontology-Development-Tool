package dblayer;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQLController extends AbstractDbController {

	public MySQLController(String dbName, String userName, String password) {
		super(dbName, userName, password);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void initConnection() {
		String url = "jdbc:mysql://localhost:3306/ontodb?autoReconnect=true&relaxAutoCommit=true";
        String user = "root";
        String password = "admin";
        

		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			   try {
		            connection = DriverManager.getConnection(url, user, password);
		            statement = connection.createStatement();
		            } catch (SQLException ex) {
		            ex.printStackTrace();
		        } 
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		}
}
