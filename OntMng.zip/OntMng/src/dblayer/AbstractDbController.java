package dblayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class AbstractDbController {
	public static Connection connection;
	public static Statement statement;
	public static ResultSet results;
	
	String dbName;
	String userName;
	String password;

	public AbstractDbController(String dbName, String userName, String password){
		this.dbName=dbName;
		this.userName=userName;
		this.password=password;
		initConnection();
	}
	public abstract void initConnection();
	
	public  Connection getConnection(){
		if(connection==null){
			initConnection();
		}
		return connection;	
	}
	
	public  void closeConnection(){
		try {
			
			if(statement!=null){
				statement.close();
			}
			if(connection!=null){
				connection.close();	
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public  void updateQuery(String sql) throws SQLException{
			if(connection==null){
				initConnection();
			}
			if(statement==null){
				statement=connection.createStatement();
			}
			statement.executeUpdate(sql);
			
			connection.commit();	
		} 
	
	
	public  ResultSet selectQuery(String sql) throws SQLException{
			if(connection==null){
			initConnection();
			}
			if(statement==null){
			statement=connection.createStatement();	
			}
				
			results = statement.executeQuery(sql);
			
			connection.commit();	
		return results;
	
	}
}
