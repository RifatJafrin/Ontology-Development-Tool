package dataaccesslayer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import model.DBConcept;
import model.Ontology;
import model.Sensor;
import dblayer.AbstractDbController;
import dblayer.MySQLController;


public class DataAccessManager {
	public static final  int DATA_PROPERTY=0;
	public static final  int OBJECT_PROPERTY=1;
	public static final  int CONCEPT_PARENT_OBSERVEDTYPE=0;
	public static final  int CONCEPT_PARENT_SENSOR=1;
	public static final  int CONCEPT_PARENT_SENSOROUTPUT=2;
	public static final  int CONCEPT_PARENT_UNIT=3;
	

	//private static DbController dbManager= new SQLDBController("db", "user", "password");
	private static AbstractDbController dbManager= new MySQLController("db", "user", "password");
	
	public static HashMap<Integer, model.DBConcept> getAllConceptRecords(int ontologyID) throws SQLException{
		HashMap<Integer,model.DBConcept> concepts= new HashMap<Integer, model.DBConcept>();
		String sql="SELECT * FROM CONCEPTS WHERE ontoID="+ ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		model.DBConcept concept= null; 
			while (rs.next()) {
				concept=new model.DBConcept();
					int id=Integer.parseInt(rs.getString("id"));
					concept.setId(id);
					concept.setConcept(rs.getString("concept"));
					concept.setParent(Integer.parseInt(rs.getString("parent")));
					
					concepts.put(id, concept);
			}
		return concepts;
	}
	
		
		
	public static HashMap<String, model.DBProperty> getAllPropertyRecords(int ontologyID) throws SQLException{
		
		HashMap<String,model.DBProperty> properties= new HashMap<String, model.DBProperty>();
		String sql="SELECT property, type, domain, ranges FROM PROPERTY WHERE ontoID=" + ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		model.DBProperty property= null; 
			while (rs.next()) {
				property=new model.DBProperty();
					String propertyName=rs.getString("property");
					property.setProperty(propertyName);
					property.setType(Integer.parseInt(rs.getString("type")));
					String domain=rs.getString("domain");
					String ranges=rs.getString("ranges");
					
					StringTokenizer tokenizer;
					
					if(domain!=null && domain.length()>0){
						tokenizer= new StringTokenizer(domain, ",");
						ArrayList<String> domains=new ArrayList<String>();
						while (tokenizer.hasMoreElements()) {
							domains.add((String)tokenizer.nextElement());
						}
						property.setDomain(domains);
							
					}
					
					if(ranges!=null && ranges.length()>0){
						tokenizer = new StringTokenizer(ranges, ",");
						ArrayList<String> rangeList=new ArrayList<String>();
						while (tokenizer.hasMoreElements()) {
							rangeList.add((String)tokenizer.nextElement());
						}
						property.setRange(rangeList);
	
					}
										
					properties.put(propertyName, property);
				}
		return properties;
	}
	
	public static int getMaxId(int ontologyID) throws SQLException{
		String sql="SELECT MAX(id) as maxID FROM CONCEPTS WHERE ontoID="+ ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		int id=-1;
			if (rs.next()) {
				String maxID=rs.getString("maxID");
				id=maxID==null?0:Integer.parseInt(maxID);
			}
		return id;
	}
		
	public static int getMaxOntologyId() throws SQLException{
		String sql="SELECT MAX(ontoID) as maxID FROM CONCEPTS";
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		int id=-1;
			if (rs.next()) {
				String maxID=rs.getString("maxID");
				id=maxID==null?0:Integer.parseInt(maxID);
			}
		return id;
	}

	public static int getGroupId(int id, int ontologyID) throws SQLException{
		String sql="SELECT grpID  FROM CONCEPTS WHERE id="+id+ " AND ontoID="+ ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		int groupID=-1;
			if (rs.next()) {
				String ID=rs.getString("grpID");
				groupID=ID==null?0:Integer.parseInt(ID);
			}
		return groupID;
	}
	
	
	public static int getId(String concept, int ontologyID) throws SQLException{
		String sql="SELECT id  FROM CONCEPTS WHERE concept='"+concept+"' AND ontoID="+ ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
		int groupID=-1;
			if (rs.next()) {
				String ID=rs.getString("id");
				groupID=ID==null?0:Integer.parseInt(ID);
			}
		return groupID;
	}
	
	public static String getOntologyName(int ontologyID) throws SQLException{
		String sql="SELECT name  FROM ontology WHERE ontoID="+ ontologyID;
		
		ResultSet rs=null;
		rs = dbManager.selectQuery(sql);
	
		String name="";
			if (rs.next()) {
				name = rs.getString("name");
			}
		return name;
	}
	
	public static void insertConcept(int id, String concept, int parent, int groupID, int ontologyID) throws SQLException{
		String sql="INSERT INTO CONCEPTS (id, concept, parent, grpID, ontoID) VALUES "+"("+id+",'"+ concept+"',"+parent+","+groupID+","+ontologyID+")";
		dbManager.updateQuery(sql);
	}
	
	public static void updateDomains(String property, String domains, int ontologyID) throws SQLException{
		if(domains==null || domains.length()==0){
			domains=new String("");
		}
		String sql="UPDATE PROPERTY SET domain='"+ domains+"'WHERE property='"+ property+"' AND ontoID="+ ontologyID;
		dbManager.updateQuery(sql);
	}
	
	public static void updateRanges(String property, String ranges, int ontologyID) throws SQLException{
		if(ranges==null || ranges.length()==0){
			ranges=new String("");
		}
		String sql="UPDATE PROPERTY SET ranges='"+ ranges+"'WHERE property='"+ property+"' AND ontoID="+ ontologyID;
		dbManager.updateQuery(sql);
	}
	
	public static String getDomains(String property, int ontologyID) throws SQLException{
		String sql="SELECT domain FROM PROPERTY WHERE property='"+ property+"' AND ontoID="+ontologyID;
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		String domains="";
			if (rs.next()) {
					domains=rs.getString("domain");
				}
		return domains;
	}
	
	public static String getRanges(String property, int ontologyID) throws SQLException{
		String sql="SELECT ranges FROM PROPERTY WHERE property='"+ property+"' AND ontoID="+ontologyID;
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		String ranges="";
			if (rs.next()) {
					ranges=rs.getString("ranges");
			}
		return ranges;
	}

	public static HashMap<Integer, ArrayList<DBConcept>> getAllConcepts(int ontologyID) throws SQLException{
		String sql="SELECT concept, id, parent, grpID FROM CONCEPTS  WHERE ontoID= "+ontologyID +" GROUP BY grpID, concept, id, parent ORDER BY id";
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		HashMap<Integer, ArrayList<DBConcept>> concepts= new HashMap<Integer, ArrayList<DBConcept>>();
		model.DBConcept concept=null;
			while (rs.next()) {
				concept= new model.DBConcept();
				concept.setConcept(rs.getString("concept"));
				concept.setId(rs.getInt("id"));
				concept.setParent(rs.getInt("parent"));
				concept.setGroupID(rs.getInt("grpID"));
				ArrayList<DBConcept> list=concepts.get(concept.getGroupID());
				if(list==null){
					list= new ArrayList<DBConcept>();
				}
				list.add(concept);
				concepts.put(concept.getGroupID(), list);
				}
		return concepts;
	}
	//----------------------new func	
	public static HashMap<Integer, ArrayList<DBConcept>> getRequiredConcept(
			String observation, int ontologyID) throws SQLException {
		
		String sql="SELECT * FROM concepts WHERE grpID=(SELECT grpID FROM concepts WHERE concept='"+ observation+ "' AND ontoID="+ ontologyID +  ")";
		
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		
		HashMap<Integer, ArrayList<DBConcept>> concepts= new HashMap<Integer, ArrayList<DBConcept>>();
		model.DBConcept concept=null;
			while (rs.next()) {
				concept= new model.DBConcept();
				concept.setConcept(rs.getString("concept"));
				concept.setId(rs.getInt("id"));
				concept.setParent(rs.getInt("parent"));
				concept.setGroupID(rs.getInt("grpID"));
				ArrayList<DBConcept> list=concepts.get(concept.getGroupID());
				if(list==null){
					list= new ArrayList<DBConcept>();
				}
				list.add(concept);
				concepts.put(concept.getGroupID(), list);
				}
		return concepts;
		
	}
	//----------------------------------------------new Func End
	public static ArrayList<String> getAllEntities(int ontologyID) throws SQLException{
		String sql="SELECT concept FROM CONCEPTS  WHERE ontoID= "+ontologyID;
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		ArrayList<String> list= new ArrayList<String>();
		
			while (rs.next()) {
				list.add(rs.getString("concept"));
				}
				
		return list;
		
	}

	public static DBConcept getConcept(
			String observation, int ontologyID) throws SQLException {
		
		String sql="SELECT * FROM concepts WHERE grpID=(SELECT grpID FROM concepts WHERE concept='"+ observation+ "' AND ontoID="+ ontologyID + ")";
		
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		
		DBConcept dbConcept= new DBConcept();
		
			if (rs.next()) {
				dbConcept.setConcept(rs.getString("concept"));
				dbConcept.setId(rs.getInt("id"));
				dbConcept.setParent(rs.getInt("parent"));
				dbConcept.setGroupID(rs.getInt("grpID"));
				}
		return dbConcept;
		
	}

	public static void updateConcept(String newObservedProperty, String oldObservedProperty, int ontologyID) throws SQLException {
		String sql="UPDATE concepts SET concept='"+ newObservedProperty +"' WHERE concept='"+ oldObservedProperty+"' AND ontoID="+ ontologyID ;
		dbManager.updateQuery(sql);
	}
	
	public static void deleteConcept(String observedProperty, int ontologyID) throws SQLException {
		String sql="DELETE FROM concepts WHERE concept='"+observedProperty +"' AND ontoID="+ ontologyID ;
		dbManager.updateQuery(sql);
	}



	public static void createProperty(String property, int type, int ontoID) throws SQLException {
		String sql="INSERT INTO PROPERTY(property, type, domain, ranges, ontoID) VALUES ('"+ property+ "',"+type +", NULL, NULL,"+ ontoID+")";
		dbManager.updateQuery(sql);
	}



	public static void deleteProperties(int ontologyID) throws SQLException {
		String sql="DELETE FROM PROPERTY WHERE ontoID='"+ontologyID;
		dbManager.updateQuery(sql);
	}



	public static void deleteConcepts(int ontologyID) throws SQLException {
		String sql="DELETE FROM CONCEPTS WHERE ontoID='"+ontologyID;
		dbManager.updateQuery(sql);
		
	}

	

	public static List<Ontology> getAllOntologies() throws SQLException {
		String sql="SELECT * FROM ontology";
		
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		
		List<Ontology> ontologies = new ArrayList<Ontology>();
			while (rs.next()) {
				Ontology ontology= new Ontology();
				ontology.setId(rs.getInt("ontoID"));
				ontology.setName(rs.getString("name"));
				ontology.setDescription(rs.getString("description"));
				ontology.setLastUpdated(rs.getString("lastUpdated"));
				ontologies.add(ontology);
			}
			
			return ontologies;
	}

	public static List<Sensor> getSensors() throws SQLException {
		String sql="SELECT * FROM SENSOR";
		
		ResultSet rs=null;
		rs=dbManager.selectQuery(sql);
		
		List<Sensor> sensors = new ArrayList<Sensor>();
			while (rs.next()) {
				Sensor sensor= new Sensor();
				sensor.setName(rs.getString("name"));
				sensor.setAttachedSensor(rs.getString("attachedSensor"));
				sensor.setSystemSpecification(rs.getString("systemSpecification"));
				sensor.setDimensions(rs.getString("dimensions"));
				sensor.setRanges(rs.getString("ranges"));
				sensor.setTotalSensorNo(rs.getString("totalSensorNo"));
				sensor.setOtherInfo(rs.getString("OtherInfo"));
				sensors.add(sensor);	
			}
			
			return sensors;
	}

	public static void insertOntology(int id, String name, String description,
			String lastUpdated) throws SQLException {
	    String sql="INSERT INTO ONTOLOGY (ontoID, name, description, lastUpdated) VALUES ("+ id+ ",'"+name+ "','"+description+ "','"+lastUpdated + "')";
		dbManager.updateQuery(sql);
	}
	
	
	public static void insertSensor(String name, String attachedSensor, String systemSpecification, String dimensions,
			String ranges, String totalSensor, String other ) throws SQLException {
		String sql="INSERT INTO SENSOR (name, attachedSensor, systemSpecification, dimensions, ranges, totalSensorNo, otherInfo) VALUES ('"+ name + "','" +attachedSensor+ "','"+systemSpecification+ "','"+ dimensions+ "','"+ranges+ "','"+totalSensor+ "','"+ other + "')";
		//String sql="INSERT INTO sensor(name, attachedSensor, systemSpecification, dimensions, ranges, totalSensorNo, otherInfo) VALUES + ("+"Sun Spot"+"," + "Temperature"+","+ "Humidity"+","+ "Light"+","+"32 bit ARM7 core - 256K RAM/2M Flash"+","+"35x25 mm"+","+ "temperature: -40~40 C"+","+ "2"+","+ "test"+")";
		
		dbManager.updateQuery(sql);
	}
	
	
}
